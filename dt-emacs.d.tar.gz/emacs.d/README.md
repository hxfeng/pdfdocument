# emacsconfigure
myemacs configure
